import os
from PIL import Image

# Input aur Output folders
input_folder = "images"
output_folder = "resized_images"

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Resize size (width, height)
size = (500, 500)

# Folder ke sabhi files par loop
for filename in os.listdir(input_folder):
    if filename.endswith((".jpg", ".jpeg", ".png")):  # sirf images hi lo
        img_path = os.path.join(input_folder, filename)
        img = Image.open(img_path)

        # Resize karna
        img = img.resize(size)

        # Output path
        output_path = os.path.join(output_folder, filename)

        # Format ko image ke extension ke hisaab se save karo
        if filename.lower().endswith(".png"):
            img.save(output_path, "PNG")
        else:
            img.save(output_path, "JPEG")

        print(f"✅ Saved: {output_path}")
